// $Id: README.txt,v 1.1.2.1 2009/12/12 15:31:54 johnalbin Exp $

To build your own Panels layout follow the documentation provided by Panels:
  http://drupal.org/node/495654

* Please note: These panels layouts will only show up if Zen is enabled. A
  bugfix is in the works for this issue: http://drupal.org/node/657720
